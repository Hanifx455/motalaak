const express = require('express');
const router = express.Router();

// سيتم استيراد وحدة التحكم بالاشتراكات لاحقاً
// const subscriptionController = require('../controllers/subscriptionController');
// const authController = require('../controllers/authController');

// مسارات مؤقتة للتوضيح

// الحصول على جميع خطط الاشتراك
router.get('/', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم استرجاع خطط الاشتراك بنجاح (هذه رسالة مؤقتة)',
    results: 3,
    data: {
      subscriptions: [
        {
          id: 'sub-1',
          name: 'مجاني',
          price: 0,
          currency: 'DZD',
          duration: 0,  // غير محدود
          features: [
            'الوصول إلى الدروس المجانية',
            'المشاركة في المنتدى',
            'إمكانية التعليق على الدروس'
          ],
          description: 'خطة مجانية تتيح الوصول إلى المحتوى الأساسي'
        },
        {
          id: 'sub-2',
          name: 'أساسي',
          price: 500,
          currency: 'DZD',
          duration: 30,  // شهر
          features: [
            'جميع مميزات الخطة المجانية',
            'الوصول إلى الدروس المتميزة',
            'تنزيل المرفقات',
            'اختبارات تفاعلية'
          ],
          description: 'خطة أساسية مناسبة للطلاب الراغبين في تحسين مستواهم'
        },
        {
          id: 'sub-3',
          name: 'احترافي',
          price: 1200,
          currency: 'DZD',
          duration: 30,  // شهر
          features: [
            'جميع مميزات الخطة الأساسية',
            'دروس خصوصية أسبوعية',
            'مراجعة الواجبات',
            'شهادات إتمام الدورات',
            'دعم فني على مدار الساعة'
          ],
          description: 'خطة احترافية شاملة للطلاب الجادين في التفوق الدراسي'
        }
      ]
    }
  });
});

// إنشاء خطة اشتراك جديدة (للمشرفين فقط)
router.post('/', (req, res) => {
  res.status(201).json({
    status: 'success',
    message: 'تم إنشاء خطة الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: {
      subscription: {
        id: 'new-sub-id',
        name: req.body.name || 'اسم الخطة',
        price: req.body.price || 0,
        currency: req.body.currency || 'DZD',
        duration: req.body.duration || 30,
        features: req.body.features || ['ميزة 1', 'ميزة 2'],
        description: req.body.description || 'وصف الخطة',
        createdAt: new Date().toISOString()
      }
    }
  });
});

// الحصول على خطة اشتراك محددة
router.get('/:id', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم استرجاع بيانات خطة الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: {
      subscription: {
        id: req.params.id,
        name: 'أساسي',
        price: 500,
        currency: 'DZD',
        duration: 30,
        features: [
          'جميع مميزات الخطة المجانية',
          'الوصول إلى الدروس المتميزة',
          'تنزيل المرفقات',
          'اختبارات تفاعلية'
        ],
        description: 'خطة أساسية مناسبة للطلاب الراغبين في تحسين مستواهم',
        createdAt: '2023-07-01',
        updatedAt: '2023-07-01'
      }
    }
  });
});

// تحديث خطة اشتراك محددة (للمشرفين فقط)
router.patch('/:id', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم تحديث بيانات خطة الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: {
      subscription: {
        id: req.params.id,
        name: req.body.name || 'اسم الخطة المحدث',
        price: req.body.price || 500,
        updatedAt: new Date().toISOString()
      }
    }
  });
});

// حذف خطة اشتراك محددة (للمشرفين فقط)
router.delete('/:id', (req, res) => {
  res.status(204).json({
    status: 'success',
    message: 'تم حذف خطة الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: null
  });
});

// الاشتراك في خطة
router.post('/subscribe', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: {
      subscription: {
        id: 'user-sub-id',
        user: 'current-user-id',
        plan: req.body.planId || 'sub-2',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),  // +30 يوم
        status: 'نشط',
        paymentMethod: req.body.paymentMethod || 'بطاقة ائتمان',
        transactionId: 'trans-123456'
      }
    }
  });
});

// إلغاء الاشتراك
router.post('/unsubscribe', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم إلغاء الاشتراك بنجاح (هذه رسالة مؤقتة)',
    data: {
      subscription: {
        id: 'user-sub-id',
        status: 'ملغي',
        cancelDate: new Date().toISOString()
      }
    }
  });
});

// الحصول على تاريخ اشتراكات المستخدم
router.get('/history/me', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'تم استرجاع تاريخ الاشتراكات بنجاح (هذه رسالة مؤقتة)',
    results: 2,
    data: {
      subscriptions: [
        {
          id: 'hist-1',
          plan: 'أساسي',
          startDate: '2023-05-01',
          endDate: '2023-06-01',
          status: 'منتهي',
          amount: 500,
          currency: 'DZD'
        },
        {
          id: 'hist-2',
          plan: 'احترافي',
          startDate: '2023-06-01',
          endDate: '2023-07-01',
          status: 'نشط',
          amount: 1200,
          currency: 'DZD'
        }
      ]
    }
  });
});

module.exports = router;