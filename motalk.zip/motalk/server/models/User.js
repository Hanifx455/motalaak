const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'يرجى إدخال اسم المستخدم'],
    unique: true,
    trim: true,
    minlength: [3, 'يجب أن يكون اسم المستخدم 3 أحرف على الأقل']
  },
  email: {
    type: String,
    required: [true, 'يرجى إدخال البريد الإلكتروني'],
    unique: true,
    lowercase: true,
    match: [/^\S+@\S+\.\S+$/, 'يرجى إدخال بريد إلكتروني صحيح']
  },
  password: {
    type: String,
    required: [true, 'يرجى إدخال كلمة المرور'],
    minlength: [8, 'يجب أن تكون كلمة المرور 8 أحرف على الأقل'],
    select: false
  },
  firstName: {
    type: String,
    required: [true, 'يرجى إدخال الاسم الأول']
  },
  lastName: {
    type: String,
    required: [true, 'يرجى إدخال الاسم الأخير']
  },
  role: {
    type: String,
    enum: ['طالب', 'معلم', 'مشرف', 'مدير'],
    default: 'طالب'
  },
  subscription: {
    type: String,
    enum: ['مجاني', 'أساسي', 'متقدم', 'احترافي'],
    default: 'مجاني'
  },
  subscriptionExpiry: {
    type: Date,
    default: null
  },
  profileImage: {
    type: String,
    default: 'default.jpg'
  },
  educationLevel: {
    type: String,
    enum: ['ابتدائي', 'متوسط', 'ثانوي', 'جامعي'],
    required: [true, 'يرجى تحديد المرحلة التعليمية']
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  active: {
    type: Boolean,
    default: true,
    select: false
  }
});

// تشفير كلمة المرور قبل الحفظ
userSchema.pre('save', async function(next) {
  // فقط إذا تم تعديل كلمة المرور
  if (!this.isModified('password')) return next();
  
  // تشفير كلمة المرور
  this.password = await bcrypt.hash(this.password, 12);
  
  next();
});

// التحقق من صحة كلمة المرور
userSchema.methods.correctPassword = async function(candidatePassword, userPassword) {
  return await bcrypt.compare(candidatePassword, userPassword);
};

const User = mongoose.model('User', userSchema);

module.exports = User;