const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'يرجى إدخال اسم الاشتراك'],
    unique: true,
    trim: true,
    enum: ['مجاني', 'أساسي', 'متقدم', 'احترافي']
  },
  price: {
    type: Number,
    required: [true, 'يرجى إدخال سعر الاشتراك']
  },
  currency: {
    type: String,
    default: 'DZD',  // الدينار الجزائري
    enum: ['DZD', 'USD', 'EUR']
  },
  duration: {
    type: Number,  // بالأيام
    required: [true, 'يرجى إدخال مدة الاشتراك']
  },
  features: [{
    type: String,
    required: [true, 'يرجى إدخال ميزات الاشتراك']
  }],
  description: {
    type: String,
    required: [true, 'يرجى إدخال وصف الاشتراك']
  },
  active: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// تحديث تاريخ التعديل قبل الحفظ
subscriptionSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Subscription = mongoose.model('Subscription', subscriptionSchema);

module.exports = Subscription;