const mongoose = require('mongoose');

const lessonSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'يرجى إدخال عنوان الدرس'],
    trim: true,
    maxlength: [100, 'يجب أن لا يتجاوز عنوان الدرس 100 حرف']
  },
  description: {
    type: String,
    required: [true, 'يرجى إدخال وصف الدرس'],
    trim: true
  },
  content: {
    type: String,
    required: [true, 'يرجى إدخال محتوى الدرس']
  },
  educationLevel: {
    type: String,
    required: [true, 'يرجى تحديد المرحلة التعليمية'],
    enum: ['ابتدائي', 'متوسط', 'ثانوي', 'جامعي']
  },
  subject: {
    type: String,
    required: [true, 'يرجى تحديد المادة الدراسية']
  },
  grade: {
    type: String,
    required: [true, 'يرجى تحديد الصف الدراسي']
  },
  isPremium: {
    type: Boolean,
    default: false
  },
  author: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: [true, 'يجب أن يكون للدرس مؤلف']
  },
  coverImage: {
    type: String,
    default: 'default-lesson.jpg'
  },
  videoUrl: {
    type: String
  },
  attachments: [{
    name: String,
    url: String
  }],
  duration: {
    type: Number,  // بالدقائق
    default: 0
  },
  tags: [String],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  views: {
    type: Number,
    default: 0
  },
  likes: {
    type: Number,
    default: 0
  },
  comments: [
    {
      user: {
        type: mongoose.Schema.ObjectId,
        ref: 'User'
      },
      text: String,
      createdAt: {
        type: Date,
        default: Date.now
      }
    }
  ],
  active: {
    type: Boolean,
    default: true
  }
});

// إنشاء فهرس للبحث النصي
lessonSchema.index({ title: 'text', description: 'text', content: 'text' });

// تحديث تاريخ التعديل قبل الحفظ
lessonSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Lesson = mongoose.model('Lesson', lessonSchema);

module.exports = Lesson;